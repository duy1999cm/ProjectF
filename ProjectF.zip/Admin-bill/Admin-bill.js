function more() {
    document.getElementById("big-box").style.display = 'none';
    document.getElementById('update-box').style.display = 'block';
}

function cancel() {
    document.getElementById('big-box').style.display = 'block';
    document.getElementById('update-box').style.display = 'none';
}