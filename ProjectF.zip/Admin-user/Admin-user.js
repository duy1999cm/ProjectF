function more() {
    // window.location = "Admin-user-update.php";
    alert('dasd');
}

// function cancel() {
//     window.location.href = "Admin-user.html";
// }