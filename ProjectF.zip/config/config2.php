<?php
    define('HOST', 'localhost');
    define('USERNAME', 'root');
    define('PASSWORD', '');
    define('DATABASE', 'sale_web');
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    session_start();